# Cubéra en ligne

1. Crée un dépôt GitHub et mets-y ces fichiers : index.html, server.js, package.json, render.yaml
2. Sur https://render.com : New → Web Service → choisis ton dépôt (offre gratuite). Build : `npm install` · Start : `npm start`
3. Render te donne une adresse https://cubera-xxxx.onrender.com : c'est ton site.
4. Pour Google : Google Search Console → ajoute ton adresse → « Demander une indexation ».

Jeu : Multijoueur → Nouveau monde (un code s'affiche) ; l'ami fait Multijoueur → Rejoindre un monde → saisit le code.
Offre gratuite : le serveur s'endort après 15 min sans visiteur (premier chargement ~30 s) ; les mondes peuvent être effacés au redémarrage.
